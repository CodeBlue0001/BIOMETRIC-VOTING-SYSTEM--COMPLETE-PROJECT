from pymongo import MongoClient
from cryptography.fernet import Fernet
client = MongoClient("mongodb+srv://User-devwithme:user-devwithme@api-checkup.it4iz.mongodb.net/?retryWrites=true&w=majority")
officer_db=client['Officer']
officer_collection=officer_db["Poling Officer"]

uid="A9715F1F"
data=officer_collection.find_one({"officer_id":uid})
print(data)
key = b'_d9SNtBvMGuEEV2vcC_FfbHzw2BSY9SQzdpNCNtEhXI='
cipher_suite = Fernet(key) 

def decrypt_data(encrypted_data):
    """
    Decrypts the given encrypted data using Fernet symmetric encryption.
    Handles both normal string data and numerical list data.
    """
    try:
        decrypted_bytes = cipher_suite.decrypt(encrypted_data)  # Decrypt the data

        try:
            # Attempt to decode as a string
            return decrypted_bytes.decode()
        except UnicodeDecodeError:
            # If decoding fails, return as a list of integers
            return list(decrypted_bytes)
    except Exception as e:
        print("Error decoding decrypted data:", e)
        return None

center=data["center"]

print(type(center))
print(decrypt_data(center))