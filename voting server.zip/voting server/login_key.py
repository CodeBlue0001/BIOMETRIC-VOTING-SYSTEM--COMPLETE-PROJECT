import requests
import webbrowser
import sys
import os
import json
def open_in_edge(url):
    if sys.platform == "win32":
        # Check typical Edge paths
        edge_paths = [
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"
        ]
        edge_path = next((path for path in edge_paths if os.path.exists(path)), None)

        if edge_path:
            webbrowser.register('edge', None, webbrowser.BackgroundBrowser(edge_path))
            webbrowser.get('edge').open_new_tab(url)
        else:
            print("❌ Microsoft Edge not found on this system.")
    else:
        print("❌ This script is for Windows systems with Edge installed.")

def login_and_open(data):
    url = "https://voteing-server-2.onrender.com"
    # url="http://127.0.0.1:3000"
    

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0"
        ),
        "Content-Type": "application/json"
    }

    try:
        response = requests.post(url, json=data, headers=headers, allow_redirects=False)
        print(response.text)
        if response.status_code == 302:  # Redirection expected
            redirect_url = response.headers.get('Location')
            print(f"✅ Login success. Opening: {redirect_url}")
            open_in_edge(redirect_url)
        else:
            print(f"❌ Login failed. Status code: {response.status_code}")
            print(f"Response: {response.text}")

    except requests.exceptions.RequestException as e:
        print(f"❌ Request error: {e}")

# Run it

data = {
        "id": "A9715F1F",
        "email": 'gAAAAABoOn4moOqtN8JM6HW5O8krukSZMDpWaYxb3KI2-i5ryog1ijFh5G96WNzeQL22fJrrrU3BEO6mfDRcgNocOlArEcTRVwqhJQeTvlEpjFdihU18nQE=',
        
        "polling_center":'gAAAAABoOn4mSb66wyqgi9WrhPuPFprYMyKdDStuqgVgAriJIDaOIECrAd5eitrP5d69nGhKEhc2lGtisApYVumm3M-bCnQZcQ=='
        # "email":"dipsardar554@gmail.com",
        # "polling_center":"CCP"
    }

login_and_open(data)
