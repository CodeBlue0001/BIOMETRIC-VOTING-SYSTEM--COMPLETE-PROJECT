import flet as ft
from pymongo import MongoClient
import random
import smtplib
import base64
from email.message import EmailMessage
import re
import hashlib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import gridfs
from cryptography.fernet import Fernet

# MongoDB Connection
# MONGO_URI = "mongodb://localhost:27017"
client = MongoClient("mongodb+srv://User-devwithme:user-devwithme@api-checkup.it4iz.mongodb.net/?retryWrites=true&w=majority")
# client = MongoClient(MONGO_URI)
db = client["Officer"]
collection = db["Poling Officer"]
fs = gridfs.GridFS(db)


key = b'_d9SNtBvMGuEEV2vcC_FfbHzw2BSY9SQzdpNCNtEhXI='
cipher_suite = Fernet(key)
# Global variables
officer_id = None

# Email Configuration
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
EMAIL_SENDER = "samridhimandal255@gmail.com"
EMAIL_PASSWORD = "vpyg fryr xgax fesm"  # Replace with app password



def encrypt_data(data):
    """
    Encrypts the given data using Fernet symmetric encryption.
    """
    if isinstance(data, str):
        data = data.encode()  # Convert string to bytes
    elif isinstance(data, list):
        data = bytes(data)  # Convert list of integers to bytes
    encrypted_data = cipher_suite.encrypt(data)
    return encrypted_data

def is_valid_email(email):
    pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return re.match(pattern, email) is not None

# OTP Storage
otp_storage = {}
is_email_veryfied=False

def send_otp(email):
    otp = str(random.randint(100000, 999999))
    otp_storage[email] = otp

    msg = EmailMessage()
    msg["Subject"] = "Your OTP Code"
    msg["From"] = EMAIL_SENDER
    msg["To"] = email
    msg.set_content(f"Your OTP is: {otp}")

    server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
    server.starttls()
    server.login(EMAIL_SENDER, EMAIL_PASSWORD)
    server.send_message(msg)
    server.quit()
    return True

def send_registration_confirmation(receiver_email, officer_id, name,password):
    try:
        sender_email = "dipayansardar477@gmail.com"
        sender_password = "issq ubqn uipo zfrf"  # Replace with app password
        subject = "Registration Confirmation"
        body = f"Hello {name}, your registration for polling officer has been successful.\n\nPlease don't share this ID and password with anyone.\n\nYour registration ID/Polling ID is {officer_id}.\nPassword:{password}"

        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))

        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver_email, msg.as_string())

        return True
    except Exception as e:
        print(f"Email sending error: {e}")
        return False

def generate_officer_id(email, mobile_number):
    username = email.split('@')[0]
    cleaned_mobile_number = re.sub(r'\D', '', mobile_number)
    combined_data = f"{username}_{cleaned_mobile_number}"
    hash_object = hashlib.sha256(combined_data.encode())
    return hash_object.hexdigest()[:8].upper()

def main(page: ft.Page):
    page.title = "User Registration"
    
    page.theme_mode = ft.ThemeMode.LIGHT
    page.window_width = 1000
    page.window_height = 900
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.CENTER

    # Show popup
    def show_popup(message):
        dialog = ft.AlertDialog(
            title=ft.Text("Notification"),
            content=ft.Text(message),
            actions=[ft.TextButton("OK", on_click=lambda e: close_popup(dialog))]
        )
        page.dialog = dialog
        dialog.open = True
        page.update()

    def close_popup(dialog):
        dialog.open = False
        page.update()

    # Form Fields
    name = ft.TextField(label="Name", width=400)
    phone = ft.TextField(label="Phone", width=400)
    email = ft.TextField(label="Email", width=400)
    otp = ft.TextField(label="Enter OTP", width=400 ,visible=False)
    password = ft.TextField(label="Password", width=400, password=True)
    center_dropdown = ft.Dropdown(
        label="Select Center",
        options=[
            ft.dropdown.Option("CCP"),
        ],
        width=400,
        hint_text="Choose a center"
    )
    def send_otp_action(e):
        if email.value and is_valid_email(email.value):
            send_otp(email.value)
            show_popup("OTP sent successfully!")
            otp.visible=True
            verify_otp_button.visible=True
        else:
            show_popup("Enter a valid email!")

    send_otp_button = ft.ElevatedButton("Verify", width=100, color=ft.colors.BLUE_800, on_click=send_otp_action)

    def verify_otp_action(e):
        if email.value in otp_storage and otp_storage[email.value] == otp.value:
            show_popup("OTP verified successfully!")
            global is_email_veryfied
            otp.visible=False
            verify_otp_button.visible=False
            is_email_veryfied=True
            del otp_storage[email.value]
        else:
            show_popup("Invalid OTP!")

    verify_otp_button = ft.ElevatedButton("Verify OTP", width=100, color=ft.colors.BLUE_900, on_click=verify_otp_action,visible=False)


    # Photo Upload Handling
    photo_display = ft.Image(width=100, height=100)

    def on_file_selected(e: ft.FilePickerResultEvent):
        if e.files:
            with open(e.files[0].path, "rb") as img_file:
                encoded_photo = base64.b64encode(img_file.read()).decode()
                photo_display.src_base64 = encoded_photo
                page.update()

    file_picker = ft.FilePicker(on_result=on_file_selected)
    page.overlay.append(file_picker)

    upload_photo_button = ft.ElevatedButton("Add A Photo", width=400, color=ft.colors.BLUE_800, on_click=lambda e: file_picker.pick_files(allow_multiple=False))

    def submit_form(e):
        global officer_id,is_email_veryfied

        if name.value and is_email_veryfied and password.value :
            # Save photo in GridFS
            photo_id = None
            if photo_display.src_base64:
                photo_data = base64.b64decode(photo_display.src_base64)
                photo_id = fs.put(photo_data, filename=f"{name.value}_photo.jpg")

            officer_id = generate_officer_id(email.value, phone.value)
            collection.insert_one({
                "name": encrypt_data(name.value),
                "phone": encrypt_data(phone.value),
                "email": encrypt_data(email.value),
                "password": encrypt_data(password.value),
                "center": encrypt_data(center_dropdown.value),
                "officer_id":str(officer_id),
                "photo_id": photo_id
            })

            show_popup("User registration successfully!")
            send_registration_confirmation(email.value, officer_id, name.value,password.value)            
            # del otp_storage[email.value]
            name.value=''
            email.value=''
            phone.value=''
            password.value=''
            center_dropdown.value = None
            photo_id=''
            photo_data=None
            photo_display.src_base64=None
            verify_otp_button.visible=False
            is_email_veryfied=False
            otp.value=''
            otp.visible=False
            page.update()
        else:
            show_popup("Please verify OTP first!")

    submit_button = ft.ElevatedButton("Submit", width=400, color=ft.colors.BLUE_800, on_click=submit_form)

    # Logo Image
    # logo = ft.Image(
    #     src="captured_photo.jpg",
    #     width=50,
    #     height=50,
    # )

    # Form Container
    form_container = ft.Container(
        content=ft.Column(
            [
                ft.Text("Officer's Register", size=35, weight=ft.FontWeight.BOLD, color=ft.colors.BLACK, text_align=ft.TextAlign.CENTER),
                name, phone,
                 ft.Row([
                     email, send_otp_button,
                 ])
                  ,
                  ft.Row([
                     otp, verify_otp_button
                 ]),
                center_dropdown,
                 password,
                upload_photo_button, photo_display,
                submit_button
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=15
        ),
        margin=5,
        padding=20,
        alignment=ft.alignment.center,
        bgcolor=ft.colors.BLUE_100,
        width=600,
        height=750,
        border_radius=70,
        border=ft.border.all(25, ft.colors.BLUE_ACCENT_700),
        shadow=ft.BoxShadow(blur_radius=10, color=ft.colors.BLACK26, offset=ft.Offset(4, 4))
    )

    # Background Container with Row Layout
    background = ft.Container(
        # image_src="capture_photo.jpg",
        # image_fit=ft.ImageFit.COVER,
        content=ft.Row(
            [
                ft.Container(width=50),
                form_container,
                ft.Container(width=50),
            ],
            alignment=ft.MainAxisAlignment.CENTER
        ),
        padding=20,
        expand=True,
    )

    # Combine logo and background
    enhanced_ui = ft.Column(
        [
            ft.Container( alignment=ft.alignment.center, padding=10),
            background
        ],
        expand=True
    )

    page.add(enhanced_ui)

ft.app(target=main)
