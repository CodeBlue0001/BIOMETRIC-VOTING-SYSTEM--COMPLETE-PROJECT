import flet as ft
from pymongo import MongoClient
from cryptography.fernet import Fernet
 
import random
# import cv2
import re
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import gridfs
from bson import ObjectId
from os import _exit as close_app
import os
import sys
import webbrowser
import requests

# MongoDB client and encryption setup
client = MongoClient("mongodb+srv://User-devwithme:user-devwithme@api-checkup.it4iz.mongodb.net/?retryWrites=true&w=majority")

# MONGO_URI = "mongodb://localhost:27017"
# client = MongoClient(MONGO_URI)
db = client["Officer"]
collection = db["Poling Officer"]
fs = gridfs.GridFS(db)

# Encryption setup
key = b'_d9SNtBvMGuEEV2vcC_FfbHzw2BSY9SQzdpNCNtEhXI='
cipher_suite = Fernet(key)

# global veriables

polling_id = ""
# uploaded_photo = None
season_data = None
otp_storage = {}


def make_json_serializable(data):
    """Recursively convert non-serializable types to serializable types."""
    if isinstance(data, ObjectId):
        return str(data)  # Convert ObjectId to string
    elif isinstance(data, bytes):
        return data.decode()  # Convert bytes to string
    elif isinstance(data, dict):
        return {key: make_json_serializable(value) for key, value in data.items()}
    elif isinstance(data, list):
        return [make_json_serializable(item) for item in data]
    else:
        return data
def open_in_edge(url):
    if sys.platform == "win32":
        # Check typical Edge paths
        edge_paths = [
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"
        ]
        edge_path = next((path for path in edge_paths if os.path.exists(path)), None)

        if edge_path:
            webbrowser.register('edge', None, webbrowser.BackgroundBrowser(edge_path))
            webbrowser.get('edge').open_new_tab(url)
        else:
            print("❌ Microsoft Edge not found on this system.")
    else:
        print("❌ This script is for Windows systems with Edge installed.")

def redirect(data):
    


    url = "https://voteing-server-2.onrender.com"
    # url="http://127.0.0.1:3000"
    

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0"
        ),
        "Content-Type": "application/json"
    }

    try:
        response = requests.post(url, json=data, headers=headers, allow_redirects=False)
        print(response.text)
        if response.status_code == 302:  # Redirection expected
            redirect_url = response.headers.get('Location')
            print(f"✅ Login success. Opening: {redirect_url}")
            open_in_edge(redirect_url)
        else:
            print(f"❌ Login failed. Status code: {response.status_code}")
            print(f"Response: {response.text}")

    except requests.exceptions.RequestException as e:
        print(f"❌ Request error: {e}")



def decrypt_data(encrypted_data):
    """
    Decrypts the given encrypted data using Fernet symmetric encryption.
    """
    decrypted_data = cipher_suite.decrypt(encrypted_data)    
    
    try:
        return decrypted_data.decode()  # Convert bytes back to string if possible
    except Exception as e:
        print("Error decoding decrypted data:", e)
        return list(encrypted_data)  # Convert bytes back to list of integers if string conversion fails


    
def generate_otp():
        return str(random.randint(100000, 999999))

def is_valid_email(email):
        pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
        return re.match(pattern, email) is not None

def send_verification_email(receiver_email, otp):
    try:
        sender_email = "dipayansardar477@gmail.com"
        sender_password = "issq ubqn uipo zfrf"
        subject = "Email Verification"
        body = f"Your OTP for verification is: {otp}\nPlease enter this OTP to verify your email."

        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))

        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver_email, msg.as_string())

        return True
    except Exception as e:
        print(f"Email sending error: {e}")
        return False

# Flet page
def main(page: ft.Page):
    page.title = "Polling Officer login"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.theme_mode = ft.ThemeMode.LIGHT

    page.theme = ft.Theme(
        color_scheme_seed=ft.Colors.LIGHT_GREEN_700
    )
    
    # Dummy data
    
    # Functions for OTP generation, email verification, etc.
    

    
    # Widgets for page layout
    polling_id_entry=ft.TextField(label="Enter Polling ID", width=400,color=ft.colors.BLACK)    
    email_field = ft.TextField(label="Enter Email", width=400,color=ft.colors.BLACK)
    password_field=ft.TextField(label='Enter Password', width=400,password=True,color=ft.colors.BLACK)
    center_dropdown = ft.Dropdown(
        label="Select Center",
        options=[
            ft.dropdown.Option("CCP"),
        ],
        width=400,
        hint_text="Choose a center"
    )
    # otp_label = ft.Text("Enter OTP", visible=False)
    otp_field = ft.TextField(label="Enter OTP",visible=False,width=400,color=ft.colors.BLACK)
    verify_otp_button = ft.ElevatedButton("Verify OTP", visible=False,width=300,color=ft.colors.LIGHT_GREEN_400)
    verify_ID_button = ft.ElevatedButton("Verify Identity")


    # result_label = ft.Text("")

    # Function to verify email
    def verify_email(e):
        global polling_id
        polling_id=polling_id_entry.value
        email = email_field.value.strip()
        password=password_field.value

        if not polling_id:
            show_popup("Please enter a polling ID.")
            return
        
        elif not email:
            show_popup("Please enter your email.")
            return
        
        elif not email or not is_valid_email(email):
            
            show_popup("Invalid email. Please enter a valid email.")
            return
        elif not password:
                    show_popup("Please enter your password.")

        else:
            
            global season_data
            season_data=collection.find_one({"officer_id":polling_id}) 
            # print(season_data)

            if not season_data:
                show_popup("Data not found. Please try again.")
                return
            # elif season_data:
        encrypted_email=season_data['email']
        decrypted_email=decrypt_data(encrypted_email)  

                
        db_password=decrypt_data(season_data['password'])

            
        if email!=decrypted_email:
                show_popup("Wrong Email.")# email checking
                
        if password != db_password :
                show_popup("Wrong Password.")# password checking
                      

        if decrypted_email==email and polling_id==season_data['officer_id'] and password==db_password:
            # page.add(ft.Text("Polling ID verified successfully!"))
            show_popup("Polling ID verified successfully!")  
            email_field.visible=False
            password_field.visible=False
            polling_id_entry.visible=False
            verify_ID_button.visible=False

            send_otp(e)
        else:            
            show_popup("Poling ID not verified with the email")
        

    

    global is_Email_verified

    def show_popup(message):
        dialog = ft.AlertDialog(
            title=ft.Text("Notification"),
            content=ft.Text(message),
            actions=[ft.TextButton("OK", on_click=lambda e: close_popup(dialog))]
        )
        page.dialog = dialog
        dialog.open = True
        page.update()

    def close_popup(dialog):
        dialog.open = False
        page.update()

    def send_otp(e):
        global otp_storage
        if not is_valid_email(email_field.value):
            show_popup("Invalid email address.")
            return

        otp = generate_otp()
        otp_storage[email_field.value] = otp
        otp_field.visible = True
        verify_otp_button.visible=True
        if send_verification_email(email_field.value, otp):
            
            show_popup("OTP sent to email.")
        else:
            show_popup("Failed to send OTP.")
        page.update()

    def verify_otp(e):
        global is_Email_verified ,polling_id
        entered_otp = otp_field.value
        if otp_storage.get(email_field.value) == entered_otp:
            is_Email_verified = True
            show_popup("Email verified successfully!")
            otp_field.visible = False
            verify_otp_button.visible=False
            verify_ID_button.visible=False
            Data={
                    "id":polling_id,
                    "email":season_data['email'],
                    "polling_center":season_data['center']                    
                }
            # Data = json.dumps(Data)
            Data=make_json_serializable(Data)

            redirect(Data) # redirecting to the website 
            page.window_close()
            # close_app(1)
            
        else:
            is_Email_verified = False
            show_popup("Invalid OTP.")
        page.update()

    

    # UI elements for email verification
    verify_ID_button.on_click = verify_email
    verify_otp_button.on_click = verify_otp

    # UI elements for fingerprint verification
    # biometric_button = ft.ElevatedButton("Verify Biometric",visible=False,on_click=match_fingerprint)

    # Layout structure
    
       
    form_container= ft.Container(
            content=ft.Column(
                [ft.Text("Officer Login",size=35, weight=ft.FontWeight.BOLD, color=ft.colors.BLACK, text_align=ft.TextAlign.CENTER),
                polling_id_entry,
                email_field,
                password_field,
                center_dropdown,
                verify_ID_button,
                otp_field,      
                          
                verify_otp_button,
                
                ]),
                    margin=10,
                    padding=10,
                    # alignment=ft.MainAxisAlignment.CENTER,
                    
                    bgcolor=ft.Colors.WHITE,
                    width=450,
                    height=500,
                    border_radius=50,
                    border=ft.border.all(15,ft.colors.BLUE_ACCENT_700),
                     shadow=ft.BoxShadow(blur_radius=10, color=ft.colors.BLACK26, offset=ft.Offset(4, 4))
                    
                    # shape=ft.RoundedRectangleBorder(radius=10)
                    
                    
   )
    
    background = ft.Container(
        # image_src="capture_photo.jpg",
        # image_fit=ft.ImageFit.COVER,
        content=ft.Row(
            [
                ft.Container(width=50),
                form_container,
                ft.Container(width=50),
            ],
            alignment=ft.MainAxisAlignment.CENTER
        ),
        padding=20,
        expand=True,
    )
    enhanced_ui = ft.Column(
        [
            ft.Container( alignment=ft.alignment.center, padding=10),
            background
        ],
        expand=True
    )
        
    page.add( enhanced_ui )

ft.app(target=main)
